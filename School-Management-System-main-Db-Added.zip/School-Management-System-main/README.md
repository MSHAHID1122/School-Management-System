# New Repository
school mangment system using html css javascript node js and mongodb
