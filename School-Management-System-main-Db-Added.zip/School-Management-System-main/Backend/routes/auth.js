const express = require("express");
const router = express.Router();
const mysql = require("mysql2");
const bcrypt = require("bcrypt"); // for hashing

// Create a connection to the database
const db = mysql.createConnection({
  host: "localhost", // host
  user: "root",      // my sql username
  password: "2021-CS-214", // my sql workbench password
  database: "school_management"
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
    return;
  }
  console.log("Connected to the database.");
});

// Signup route
router.post("/signup", async (req, res) => {
    const { name, email, phone, role, password } = req.body;
  
    // Check if the user already exists
    db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
      if (err) {
        return res.status(500).json({ message: "Database error!" });
      }
      if (results.length > 0) {
        return res.status(400).json({ message: "User already exists!" });
      }
  
      // Hash the password before storing
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Store new user data in the database
      db.query(
        "INSERT INTO users (name, username, email, phone, password, role) VALUES (?, ?, ?, ?, ?, ?)",
        [name, email, email, phone, hashedPassword, role],
        (err, results) => {
          if (err) {
            return res.status(500).json({ message: "Database error!" });
          }
          res.status(201).json({ message: "User registered successfully!" });
        }
      );
    });
  });

// Login route
router.post("/login", (req, res) => {
    const { email, password } = req.body;
  
    // Check if user exists
    db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
      if (err) {
        return res.status(500).json({ message: "Database error!" });
      }
      if (results.length === 0) {
        return res.status(401).json({ message: "Invalid credentials!" });
      }
  
      const user = results[0];
  
      // Compare the hashed password
      bcrypt.compare(password, user.password, (err, match) => {
        if (err) {
          return res.status(500).json({ message: "Error checking password!" });
        }
        if (!match) {
          return res.status(401).json({ message: "Invalid credentials!" });
        }
  
        res.status(200).json({ message: `Welcome back, ${user.name}!` });
      });
    });
  });

module.exports = router;
